package CRUD.ET1.interfaces;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import CRUD.ET1.modelo.Productos;
@Repository
public interface IProductos extends JpaRepository<Productos, Integer> {

}
