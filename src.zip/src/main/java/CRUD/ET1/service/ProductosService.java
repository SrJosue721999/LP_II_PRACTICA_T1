package CRUD.ET1.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import CRUD.ET1.interfaceService.IProductosService;
import CRUD.ET1.interfaces.IProductos;
import CRUD.ET1.modelo.Productos;

@Service
public class ProductosService implements IProductosService {

	@Autowired
	private IProductos datos;
	
	
	@Override
	public List<Productos> Listado() {
		return (List<Productos>)datos.findAll();
	}

	@Override
	public Optional<Productos> Buscar(int id) {
		
		return datos.findById(id);
	}

	@Override
	public void Insertar(Productos p) {
		
		datos.save(p);
		
	}

	@Override
	public void Modificar(Productos p) {
		datos.save(p);
		
	}

	@Override
	public void Suprimir(int id) {
		datos.deleteById(id);
		
	}

}
