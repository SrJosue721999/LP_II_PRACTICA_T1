package CRUD.ET1.controlador;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import CRUD.ET1.modelo.Productos;
import java.util.List;
import java.util.Optional;

import CRUD.ET1.interfaceService.IProductosService;

@Controller
@RequestMapping
public class Controlador {

	@Autowired
	private IProductosService servicio;
	
	
	@GetMapping ("/listar")
	public String Listar(Model modelo) {
		
		List<Productos>producto  = servicio.Listado();
		modelo.addAttribute("producto" , producto);
		return "index";
	}
	
	@GetMapping("/new")
	public String agregar(Model modelo) {
		modelo.addAttribute("producto", new Productos());
		return "form";
	}
	
	@PostMapping("/save")
	public String save (@Validated Productos p , Model modelo) {
		servicio.Insertar(p);
		return "redirect:/listar";
	}
	
	
	@GetMapping("/editar/{id}")
	public String editar(@PathVariable int id , Model modelo) {
		Optional<Productos> p = servicio.Buscar(id);
		modelo.addAttribute("producto", p);
		return "form";
	}
	
	//	ELIMINAR
	@GetMapping("/eliminar/{id}")
	public String eliminar(@PathVariable int id , Model modelo) {
		 servicio.Suprimir(id);
	 return "redirect:/listar";
	}
	
	
}
