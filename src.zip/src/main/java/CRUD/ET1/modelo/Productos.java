package CRUD.ET1.modelo;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="productos")

public class Productos {

@Id
@GeneratedValue(strategy = GenerationType.IDENTITY) 

private int id;
private String codigo;
private String descripcion;
private double preciocompra;
private double precioventa;
private int existencia;


//CONSTRUCTORES 

public Productos() {
}


public Productos(int id, String codigo, double preciocompra, double precioventa, int existencia) {
	this.id = id;
	this.codigo = codigo;
	this.preciocompra = preciocompra;
	this.precioventa = precioventa;
	this.existencia = existencia;
}


//setter y getters

public int getId() {
	return id;
}


public void setId(int id) {
	this.id = id;
}


public String getCodigo() {
	return codigo;
}


public void setCodigo(String codigo) {
	this.codigo = codigo;
}


public double getPreciocompra() {
	return preciocompra;
}


public void setPreciocompra(double preciocompra) {
	this.preciocompra = preciocompra;
}


public double getPrecioventa() {
	return precioventa;
}


public void setPrecioventa(double precioventa) {
	this.precioventa = precioventa;
}


public String getDescripcion() {
	return descripcion;
}


public void setDescripcion(String descripcion) {
	this.descripcion = descripcion;
}

public int getExistencia() {
	return existencia;
}


public void setExistencia(int existencia) {
	this.existencia = existencia;
}



	




}
