package CRUD.ET1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExamenT1LpApplicationTests {

	@Test
	void contextLoads() {
	}

}
